import Link from "next/link"
import { Mail, Phone } from "lucide-react"

export function Footer() {
  return (
    <footer id="kontakt" className="border-t bg-card">
      <div className="container py-12">
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
          <div id="ueber-uns">
            <Link href="/" className="flex items-center mb-4">
              <span className="font-bold text-xl text-primary">1of10</span>
            </Link>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Ihr zuverlässiger Partner für günstige Software. Wir bieten Ihnen hochwertige Lizenzschlüssel zu fairen Preisen.
            </p>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4 text-foreground">Produkte</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/#produkte" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Antivirus-Software
                </Link>
              </li>
              <li>
                <Link href="/#produkte" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  PC-Optimierung
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4 text-foreground">Rechtliches</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/impressum" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Impressum
                </Link>
              </li>
              <li>
                <Link href="/datenschutz" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Datenschutz
                </Link>
              </li>
              <li>
                <Link href="/agb" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  AGB
                </Link>
              </li>
              <li>
                <Link href="/widerruf" className="text-sm text-muted-foreground hover:text-primary transition-colors">
                  Widerruf
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="text-sm font-semibold mb-4 text-foreground">Kontakt</h3>
            <ul className="space-y-3">
              <li className="flex items-center text-sm text-muted-foreground">
                <Mail className="h-4 w-4 mr-2" />
                kontakt@1of10.de
              </li>
              <li className="flex items-center text-sm text-muted-foreground">
                <Phone className="h-4 w-4 mr-2" />
                +49 (0) 123 456789
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-10 border-t pt-8 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm text-muted-foreground">
            © {new Date().getFullYear()} 1of10. Alle Rechte vorbehalten.
          </p>
          <p className="text-xs text-muted-foreground">
            Alle Preise inkl. MwSt.
          </p>
        </div>
      </div>
    </footer>
  )
}
