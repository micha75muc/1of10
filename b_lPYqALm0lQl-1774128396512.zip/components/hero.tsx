import { Button } from "@/components/ui/button"
import { Gift, Shield, Zap } from "lucide-react"
import Link from "next/link"

export function Hero() {
  return (
    <div className="relative">
      {/* USP Banner */}
      <div className="bg-accent text-accent-foreground py-3 px-4 text-center font-medium">
        <Gift className="inline-block h-5 w-5 mr-2 -mt-0.5" />
        Wir erstatten jeden 10. Kauf — als freiwillige Kulanzleistung
      </div>
      
      {/* Hero Section */}
      <div className="bg-gradient-to-b from-primary/5 to-background">
        <div className="mx-auto max-w-5xl px-6 py-20 sm:py-28 lg:px-8">
          <div className="mx-auto max-w-3xl text-center">
            <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl lg:text-6xl text-balance">
              Software günstig und sicher kaufen
            </h1>
            <p className="mt-6 text-lg leading-8 text-muted-foreground">
              Bei 1of10 erhalten Sie hochwertige Sicherheitssoftware zu fairen Preisen. 
              Sofortige Lieferung Ihrer Lizenzschlüssel per E-Mail.
            </p>
            <div className="mt-10 flex items-center justify-center gap-x-4">
              <Link href="#produkte">
                <Button size="lg">
                  Jetzt einkaufen
                </Button>
              </Link>
            </div>
          </div>
          
          {/* Trust Indicators */}
          <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-3">
            <div className="flex flex-col items-center text-center p-4">
              <div className="rounded-full bg-primary/10 p-3 mb-3">
                <Zap className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">Sofortige Lieferung</h3>
              <p className="text-sm text-muted-foreground mt-1">Lizenzschlüssel direkt per E-Mail</p>
            </div>
            <div className="flex flex-col items-center text-center p-4">
              <div className="rounded-full bg-primary/10 p-3 mb-3">
                <Shield className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">Sichere Zahlung</h3>
              <p className="text-sm text-muted-foreground mt-1">SSL-verschlüsselt und geschützt</p>
            </div>
            <div className="flex flex-col items-center text-center p-4">
              <div className="rounded-full bg-primary/10 p-3 mb-3">
                <Gift className="h-6 w-6 text-primary" />
              </div>
              <h3 className="font-semibold text-foreground">Jeder 10. Kauf gratis</h3>
              <p className="text-sm text-muted-foreground mt-1">Freiwillige Kulanzerstattung</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
