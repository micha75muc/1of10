import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check, ShoppingCart } from "lucide-react"

const products = [
  {
    id: 1,
    title: "Norton 360 Standard",
    description: "Umfassender Schutz für Ihren PC mit Antivirus, VPN und Passwort-Manager. 1 Gerät, 1 Jahr.",
    price: "14,99",
    originalPrice: "44,99",
    category: "Antivirus",
    features: ["Echtzeitschutz", "VPN inklusive", "Passwort-Manager"],
  },
  {
    id: 2,
    title: "McAfee Total Protection",
    description: "Schützen Sie Ihre gesamte Familie mit einem Abonnement. Unbegrenzte Geräte, 1 Jahr.",
    price: "19,99",
    originalPrice: "59,99",
    category: "Antivirus",
    features: ["Unbegrenzte Geräte", "Identitätsschutz", "Sichere VPN"],
  },
  {
    id: 3,
    title: "Avast Premium Security",
    description: "Fortschrittlicher Schutz vor Viren, Ransomware und Phishing-Angriffen. 1 Gerät, 1 Jahr.",
    price: "24,99",
    originalPrice: "69,99",
    category: "Antivirus",
    features: ["Anti-Ransomware", "Webcam-Schutz", "Firewall"],
  },
  {
    id: 4,
    title: "AVG TuneUp",
    description: "Optimieren Sie Ihren PC für maximale Leistung. Automatische Wartung und Bereinigung.",
    price: "39,99",
    originalPrice: "89,99",
    category: "Optimierung",
    features: ["PC-Beschleunigung", "Speicherbereinigung", "Auto-Update"],
  },
]

export function FeaturedPrompts() {
  return (
    <section id="produkte" className="py-16 px-6 bg-muted/30">
      <div className="mx-auto max-w-7xl">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold tracking-tight text-foreground">Unsere Produkte</h2>
          <p className="mt-3 text-muted-foreground">Hochwertige Software zu günstigen Preisen</p>
        </div>
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {products.map((product) => (
            <Card key={product.id} className="group relative overflow-hidden transition-all hover:shadow-lg bg-card">
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <Badge variant="secondary" className="text-xs">{product.category}</Badge>
                </div>
                <CardTitle className="text-lg">{product.title}</CardTitle>
                <CardDescription className="text-sm mt-2 line-clamp-2">{product.description}</CardDescription>
              </CardHeader>
              <CardContent className="pb-3">
                <ul className="space-y-2">
                  {product.features.map((feature, index) => (
                    <li key={index} className="flex items-center text-sm text-muted-foreground">
                      <Check className="h-4 w-4 text-primary mr-2 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </CardContent>
              <CardFooter className="flex flex-col items-start gap-3 pt-3 border-t">
                <div className="flex items-baseline gap-2">
                  <span className="text-2xl font-bold text-foreground">{product.price} €</span>
                  <span className="text-sm text-muted-foreground line-through">{product.originalPrice} €</span>
                </div>
                <Button className="w-full">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  In den Warenkorb
                </Button>
              </CardFooter>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
