"use client"

import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { Menu, ShoppingCart } from "lucide-react"
import Link from "next/link"

export function Navigation() {
  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-8 flex items-center space-x-2">
            <span className="font-bold text-xl text-primary">1of10</span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            <Link href="/#produkte" className="transition-colors hover:text-primary text-foreground">
              Produkte
            </Link>
            <Link href="/#ueber-uns" className="transition-colors hover:text-primary text-foreground">
              Über uns
            </Link>
            <Link href="/#kontakt" className="transition-colors hover:text-primary text-foreground">
              Kontakt
            </Link>
          </nav>
        </div>
        <Sheet>
          <SheetTrigger asChild>
            <Button
              variant="ghost"
              className="mr-2 px-0 text-base hover:bg-transparent focus-visible:bg-transparent focus-visible:ring-0 focus-visible:ring-offset-0 md:hidden"
            >
              <Menu className="h-6 w-6" />
              <span className="sr-only">Menü öffnen</span>
            </Button>
          </SheetTrigger>
          <SheetContent side="left" className="pr-0">
            <Link href="/" className="flex items-center mb-6">
              <span className="font-bold text-xl text-primary">1of10</span>
            </Link>
            <nav className="grid gap-6 px-2 py-6">
              <Link href="/#produkte" className="hover:text-primary">
                Produkte
              </Link>
              <Link href="/#ueber-uns" className="hover:text-primary">
                Über uns
              </Link>
              <Link href="/#kontakt" className="hover:text-primary">
                Kontakt
              </Link>
            </nav>
          </SheetContent>
        </Sheet>
        <div className="flex flex-1 items-center justify-end space-x-4">
          <Link href="/" className="md:hidden">
            <span className="font-bold text-xl text-primary">1of10</span>
          </Link>
          <div className="hidden md:flex items-center">
            <Button variant="outline" size="sm">
              <ShoppingCart className="mr-2 h-4 w-4" />
              Warenkorb
            </Button>
          </div>
        </div>
      </div>
    </header>
  )
}
